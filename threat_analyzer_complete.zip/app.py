from flask import Flask, request, jsonify
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

app = Flask(__name__)

# Sample data    
train_texts = [
    "Click here to reset your password",
    "Verify your account immediately",
    "Meeting at 10am tomorrow",
    "Lunch plans?",
    "Urgent! Your account is compromised",
    "Let's catch up soon"
]
train_labels = [1, 1, 0, 0, 1, 0]

# Train model
model = Pipeline([
    ('vectorizer', TfidfVectorizer()),
    ('classifier', LogisticRegression())
])
model.fit(train_texts, train_labels)

def rule_based_flags(text):
    suspicious_keywords = ['urgent', 'click here', 'verify', 'password reset']
    if any(kw in text.lower() for kw in suspicious_keywords):
        return True
    if re.search(r'https?://[^\s]+', text) and 'trusted-domain.com' not in text:
        return True
    return False

def analyze_message(message):
    ml_prediction = model.predict([message])[0]
    rule_flag = rule_based_flags(message)
    return {
        "message": message,
        "threat": bool(ml_prediction or rule_flag),
        "ml_flag": bool(ml_prediction),
        "rule_flag": rule_flag
    }

@app.route("/analyze", methods=["POST"])
def analyze():
    data = request.json
    message = data.get("message", "")
    result = analyze_message(message)
    return jsonify(result)

if __name__ == "__main__":
    app.run(port=5000)
